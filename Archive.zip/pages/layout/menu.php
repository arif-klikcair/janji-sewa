<header>
    <img src="assets/images/logo-janjisewa.png" class="logo" alt="Logo Janji Sewa" />
</header>