<header>
    <a href="<?=base_url();?>" class="no-style">
        <img src="assets/images/logo-janjisewa.png" class="logo" alt="Logo Janji Sewa" />
    </a>
</header>