<footer>
    <div class="contact-us d-flex flex-column">
        <span class="d-block">Punya pertanyaan seputar janjisewa ? hubungi kami disini,</span>
        <span class="d-none"><b>Telp.</b> <?=$contact_telp?></span>
        <span><b>Email.</b> <a class="no-style" href="mailto:<?=$contact_email?>"><?=$contact_email?></a></span>
    </div>

    <div class="menu-bottom d-flex align-items-center justify-content-between">
        <div>
            <a href="<?=base_url();?>/tentang-kami">Tentang Kami</a>
            <a href="<?=base_url();?>/faq">FAQ</a>
        </div>
        <div class="sharethis-inline-share-buttons"></div>
    </div>
</footer>