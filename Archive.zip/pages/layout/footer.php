<footer>
    <div class="contact-us d-flex flex-column">
        <span class="d-block">Punya pertanyaan seputar janjisewa ? hubungi kami disini,</span>
        <span><b>Telp.</b> <?=$contact_telp?></span>
        <span><b>Email.</b> <?=$contact_email?></span>
    </div>

    <div class="menu-bottom">
        <a target="_blank" href="<?=$link_tentangkami?>">Tentang Kami</a>
        <a target="_blank" href="<?=$link_faq?>">FAQ</a>
    </div>
</footer>